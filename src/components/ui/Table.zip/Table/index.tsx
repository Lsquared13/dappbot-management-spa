import Table from "./Table";
export * from "./Table";
export default Table;
